import{p}from"../../chunks/_page-d86dbbba.js";export{p as prerender};

import{l as a,p as o}from"../../../chunks/_page-c4db679d.js";export{a as load,o as prerender};

import{l as a,p as o}from"../../../chunks/_page-47ef26a4.js";export{a as load,o as prerender};

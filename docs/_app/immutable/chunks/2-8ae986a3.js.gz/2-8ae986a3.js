import{_ as r}from"./_page-da46b06b.js";import{default as t}from"../components/pages/_page.svelte-70c9fc76.js";export{t as component,r as shared};

import{default as t}from"../components/error.svelte-41dd6b6a.js";export{t as component};

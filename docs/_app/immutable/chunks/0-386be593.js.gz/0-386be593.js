import{default as t}from"../components/pages/_layout.svelte-89a1a053.js";export{t as component};

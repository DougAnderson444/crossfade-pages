import{default as t}from"../components/error.svelte-c72d6c0c.js";export{t as component};

import{_ as r}from"./_page-47ef26a4.js";import{default as t}from"../components/pages/_pageId_/_page.svelte-a7224199.js";export{t as component,r as shared};

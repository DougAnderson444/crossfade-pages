import{default as t}from"../components/pages/_layout.svelte-8350e9ce.js";export{t as component};

import{default as t}from"../components/error.svelte-936596db.js";export{t as component};

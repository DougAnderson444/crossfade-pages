import{default as t}from"../components/pages/_layout.svelte-ac263475.js";export{t as component};

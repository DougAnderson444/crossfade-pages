import{_ as r}from"./_page-c4db679d.js";import{default as t}from"../components/pages/_pageId_/_page.svelte-0ab2d258.js";export{t as component,r as shared};

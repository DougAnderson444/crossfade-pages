import{default as t}from"../components/pages/_layout.svelte-eb65274f.js";export{t as component};

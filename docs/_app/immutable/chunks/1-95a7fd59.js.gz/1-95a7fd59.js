import{default as t}from"../components/error.svelte-d381978e.js";export{t as component};

import{default as t}from"../components/pages/_layout.svelte-9066f854.js";export{t as component};

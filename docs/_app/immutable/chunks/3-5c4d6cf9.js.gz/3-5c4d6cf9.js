import{_ as r}from"./_page-c4db679d.js";import{default as t}from"../components/pages/_pageId_/_page.svelte-9ce24ec4.js";export{t as component,r as shared};

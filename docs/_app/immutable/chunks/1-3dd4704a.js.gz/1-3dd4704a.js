import{default as t}from"../components/error.svelte-2db24a00.js";export{t as component};

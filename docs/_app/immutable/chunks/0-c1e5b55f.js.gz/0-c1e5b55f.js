import{default as t}from"../components/pages/_layout.svelte-8c7591b8.js";export{t as component};

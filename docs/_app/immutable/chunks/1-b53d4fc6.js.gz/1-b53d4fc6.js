import{default as t}from"../components/error.svelte-021661f0.js";export{t as component};

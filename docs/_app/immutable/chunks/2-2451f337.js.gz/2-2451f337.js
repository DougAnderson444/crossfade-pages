import{_ as r}from"./_page-d86dbbba.js";import{default as t}from"../components/pages/_page.svelte-5d56351e.js";export{t as component,r as shared};

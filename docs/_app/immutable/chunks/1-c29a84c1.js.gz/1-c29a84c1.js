import{default as t}from"../components/error.svelte-4c76c42d.js";export{t as component};
